LIFEPASS PWA

This version keeps the existing LIFEPASS frontend and adds installable PWA support.

Upload these files/folders to the same GitHub Pages repository root:
- index.html
- manifest.webmanifest
- sw.js
- icons/icon-192.png
- icons/icon-512.png

Then open https://lifepassdigital.github.io/lifepass/ in Chrome. The browser may show an Install LIFEPASS option. On desktop, use the install icon in the address bar or Chrome menu. On Android Chrome, use the menu and Install app / Add to Home screen when offered.
